options(stringsAsFactors = FALSE, scipen = 999)

# ============================================================

# DAY 6.4 - R IMPLEMENTATION

# Convexity Sensitivity AI Agent

# ============================================================

# ------------------------------------------------------------

# 1. FIND PROJECT ROOT

# ------------------------------------------------------------

args <- commandArgs(trailingOnly = FALSE)

file_arg <- grep("^--file=", args, value = TRUE)

if (length(file_arg) > 0) {
script_path <- sub("^--file=", "", file_arg[1])
script_path <- normalizePath(
script_path,
winslash = "/",
mustWork = TRUE
)
SCRIPT_DIR <- dirname(script_path)
} else {
SCRIPT_DIR <- getwd()
}

BASE_DIR <- normalizePath(
file.path(SCRIPT_DIR, ".."),
winslash = "/",
mustWork = FALSE
)

DATA_DIR <- file.path(
BASE_DIR,
"data"
)

OUTPUT_DIR <- file.path(
BASE_DIR,
"outputs"
)

R_OUTPUT_DIR <- file.path(
OUTPUT_DIR,
"r_results"
)

if (!dir.exists(R_OUTPUT_DIR)) {
dir.create(
R_OUTPUT_DIR,
recursive = TRUE
)
}

cat("\n")
cat("============================================\n")
cat(" DAY 6.4 - R RISK ANALYSIS\n")
cat("============================================\n\n")

# ------------------------------------------------------------

# 2. LOAD DATA

# ------------------------------------------------------------

portfolio_file <- file.path(
DATA_DIR,
"bond_portfolio_data.csv"
)

curve_file <- file.path(
DATA_DIR,
"yield_curve_history.csv"
)

mc_file <- file.path(
DATA_DIR,
"monte_carlo_scenarios.csv"
)

portfolio <- read.csv(
portfolio_file,
check.names = FALSE
)

yield_curve <- read.csv(
curve_file,
check.names = FALSE
)

monte_carlo <- read.csv(
mc_file,
check.names = FALSE
)

cat("Data loaded successfully.\n")
cat(
"Portfolio rows    :",
nrow(portfolio),
"\n"
)

cat(
"Yield curve rows  :",
nrow(yield_curve),
"\n"
)

cat(
"Monte Carlo rows  :",
nrow(monte_carlo),
"\n\n"
)

# ------------------------------------------------------------

# 3. PORTFOLIO RISK METRICS

# ------------------------------------------------------------

total_mv <- sum(
portfolio$MarketValue_INR,
na.rm = TRUE
)

portfolio_duration <- sum(
portfolio$ModifiedDuration *
portfolio$PortfolioWeight,
na.rm = TRUE
)

portfolio_convexity <- sum(
portfolio$Convexity *
portfolio$PortfolioWeight,
na.rm = TRUE
)

portfolio_dv01 <- sum(
portfolio$DV01_Per100Face *
portfolio$Quantity /
100,
na.rm = TRUE
)

portfolio_summary <- data.frame(
Metric = c(
"Market Value",
"Modified Duration",
"Convexity",
"DV01"
),
Value = c(
total_mv,
portfolio_duration,
portfolio_convexity,
portfolio_dv01
)
)

write.csv(
portfolio_summary,
file.path(
R_OUTPUT_DIR,
"r_portfolio_summary.csv"
),
row.names = FALSE
)

cat("PORTFOLIO RISK METRICS\n")
cat("--------------------------------------------\n")

cat(
sprintf(
"Market Value       : INR %.2f\n",
total_mv
)
)

cat(
sprintf(
"Modified Duration  : %.6f\n",
portfolio_duration
)
)

cat(
sprintf(
"Convexity          : %.6f\n",
portfolio_convexity
)
)

cat(
sprintf(
"DV01               : INR %.2f\n\n",
portfolio_dv01
)
)

# ------------------------------------------------------------

# 4. STRESS TESTING

# Formula:

# ΔP/P = -D × Δy + 0.5 × C × (Δy)^2

# ------------------------------------------------------------

shocks_bps <- c(
-200,
-100,
-50,
50,
100,
200
)

stress_results <- data.frame(
YieldShock_bps = shocks_bps,
DurationEffect_INR = NA_real_,
ConvexityEffect_INR = NA_real_,
TotalPnL_INR = NA_real_
)

for (i in seq_along(shocks_bps)) {

dy <- shocks_bps[i] / 10000

duration_effect <-
-portfolio_duration *
dy *
total_mv

convexity_effect <-
0.5 *
portfolio_convexity *
dy^2 *
total_mv

total_pnl <-
duration_effect +
convexity_effect

stress_results$DurationEffect_INR[i] <-
duration_effect

stress_results$ConvexityEffect_INR[i] <-
convexity_effect

stress_results$TotalPnL_INR[i] <-
total_pnl
}

write.csv(
stress_results,
file.path(
R_OUTPUT_DIR,
"r_stress_test_results.csv"
),
row.names = FALSE
)

cat("STRESS TESTING\n")
cat("--------------------------------------------\n")

print(
stress_results,
row.names = FALSE
)

cat("\n")

# ------------------------------------------------------------

# 5. KEY RATE DURATION

# ------------------------------------------------------------

krd_values <- aggregate(
ModifiedDuration * PortfolioWeight ~ KeyRateBucket,
data = portfolio,
FUN = function(x) {
sum(x, na.rm = TRUE)
}
)

names(krd_values)[2] <- "KRD"

bucket_order <- c(
"0-1Y",
"1-2Y",
"2-3Y",
"3-5Y",
"5-7Y",
"7-10Y",
"10-15Y",
"15-20Y",
"20Y+"
)

krd_values$KeyRateBucket <- factor(
krd_values$KeyRateBucket,
levels = bucket_order
)

krd_values <- krd_values[
order(krd_values$KeyRateBucket),
]

krd_values$KeyRateBucket <- as.character(
krd_values$KeyRateBucket
)

write.csv(
krd_values,
file.path(
R_OUTPUT_DIR,
"r_krd_analysis.csv"
),
row.names = FALSE
)

cat("KEY RATE DURATION\n")
cat("--------------------------------------------\n")

print(
krd_values,
row.names = FALSE
)

cat("\n")

# ------------------------------------------------------------

# 6. LATEST YIELD CURVE

# ------------------------------------------------------------

yield_curve$CurveDate <- as.Date(
yield_curve$CurveDate
)

latest_date <- max(
yield_curve$CurveDate,
na.rm = TRUE
)

latest_curve <- yield_curve[
yield_curve$CurveDate == latest_date,
]

latest_curve <- latest_curve[
order(latest_curve$Tenor_Years),
]

write.csv(
latest_curve,
file.path(
R_OUTPUT_DIR,
"r_latest_yield_curve.csv"
),
row.names = FALSE
)

cat("LATEST YIELD CURVE\n")
cat("--------------------------------------------\n")

cat(
"Curve Date:",
as.character(latest_date),
"\n"
)

print(
latest_curve[
,
c(
"TenorLabel",
"Tenor_Years",
"Yield",
"ZeroRate",
"ForwardRate"
)
],
row.names = FALSE
)

cat("\n")

# ------------------------------------------------------------

# 7. YIELD CURVE SCENARIOS

# ------------------------------------------------------------

buckets <- c(
"0-1Y",
"1-2Y",
"2-3Y",
"3-5Y",
"5-7Y",
"7-10Y",
"10-15Y",
"15-20Y",
"20Y+"
)

parallel_up <- c(
50,
50,
50,
50,
50,
50,
50,
50,
50
)

parallel_down <- c(
-50,
-50,
-50,
-50,
-50,
-50,
-50,
-50,
-50
)

steepening <- c(
5,
10,
15,
20,
30,
40,
42,
45,
50
)

flattening <- c(
50,
45,
40,
30,
20,
15,
10,
5,
0
)

butterfly <- c(
10,
20,
30,
40,
50,
50,
50,
40,
20
)

# ------------------------------------------------------------

# SCENARIO P&L FUNCTION

# ------------------------------------------------------------

scenario_pnl <- function(shifts) {

pnl <- 0

for (i in seq_along(buckets)) {

bucket <- buckets[i]

krd_index <- match(
  bucket,
  krd_values$KeyRateBucket
)

if (is.na(krd_index)) {

  duration <- 0

} else {

  duration <- krd_values$KRD[
    krd_index
  ]
}

shift_bps <- shifts[i]

shift <- shift_bps / 10000

pnl <- pnl -
  duration *
  shift *
  total_mv

}

return(pnl)
}

# ------------------------------------------------------------

# CALCULATE ALL SCENARIOS

# ------------------------------------------------------------

scenario_names <- c(
"Parallel +50 bps",
"Parallel -50 bps",
"Steepening",
"Flattening",
"Butterfly"
)

scenario_shifts <- list(
parallel_up,
parallel_down,
steepening,
flattening,
butterfly
)

scenario_pnl_values <- sapply(
scenario_shifts,
scenario_pnl
)

curve_scenario_results <- data.frame(
Scenario = scenario_names,
PnL_INR = as.numeric(
scenario_pnl_values
)
)

write.csv(
curve_scenario_results,
file.path(
R_OUTPUT_DIR,
"r_curve_scenario_results.csv"
),
row.names = FALSE
)

cat("YIELD CURVE SCENARIOS\n")
cat("--------------------------------------------\n")

print(
curve_scenario_results,
row.names = FALSE
)

cat("\n")

# ------------------------------------------------------------

# 8. MONTE CARLO VaR / CVaR

# ------------------------------------------------------------

pnl <- monte_carlo$PnL_Total_INR

var_threshold <- as.numeric(
quantile(
pnl,
probs = 0.05,
na.rm = TRUE,
names = FALSE
)
)

var_95 <- -var_threshold

tail_pnl <- pnl[
pnl <= var_threshold
]

cvar_95 <- -mean(
tail_pnl,
na.rm = TRUE
)

mc_summary <- data.frame(
Metric = c(
"Minimum PnL",
"Maximum PnL",
"Mean PnL",
"Median PnL",
"Standard Deviation",
"VaR 95%",
"CVaR 95%"
),
Value_INR = c(
min(pnl, na.rm = TRUE),
max(pnl, na.rm = TRUE),
mean(pnl, na.rm = TRUE),
median(pnl, na.rm = TRUE),
sd(pnl, na.rm = TRUE),
var_95,
cvar_95
)
)

write.csv(
mc_summary,
file.path(
R_OUTPUT_DIR,
"r_monte_carlo_summary.csv"
),
row.names = FALSE
)

cat("MONTE CARLO RISK\n")
cat("--------------------------------------------\n")

print(
mc_summary,
row.names = FALSE
)

cat("\n")

# ------------------------------------------------------------

# 9. MACHINE LEARNING MODEL COMPARISON

# ------------------------------------------------------------

ml_file <- file.path(
OUTPUT_DIR,
"ml_model_comparison.csv"
)

feature_file <- file.path(
OUTPUT_DIR,
"ml_feature_importance.csv"
)

if (file.exists(ml_file)) {

ml_models <- read.csv(
ml_file,
check.names = FALSE
)

write.csv(
ml_models,
file.path(
R_OUTPUT_DIR,
"r_ml_model_comparison.csv"
),
row.names = FALSE
)

cat("MACHINE LEARNING MODEL COMPARISON\n")
cat("--------------------------------------------\n")

print(
ml_models,
row.names = FALSE
)

cat("\n")

} else {

cat(
"ML model comparison file not found.\n\n"
)
}

if (file.exists(feature_file)) {

feature_importance <- read.csv(
feature_file,
check.names = FALSE
)

write.csv(
feature_importance,
file.path(
R_OUTPUT_DIR,
"r_ml_feature_importance.csv"
),
row.names = FALSE
)

cat("ML FEATURE IMPORTANCE\n")
cat("--------------------------------------------\n")

print(
feature_importance,
row.names = FALSE
)

cat("\n")
}

# ------------------------------------------------------------

# 10. COMBINED RISK REPORT

# ------------------------------------------------------------

combined_report <- data.frame(
Metric = c(
"Portfolio Market Value",
"Portfolio Modified Duration",
"Portfolio Convexity",
"Portfolio DV01",
"Monte Carlo VaR 95%",
"Monte Carlo CVaR 95%"
),
Value = c(
total_mv,
portfolio_duration,
portfolio_convexity,
portfolio_dv01,
var_95,
cvar_95
)
)

write.csv(
combined_report,
file.path(
R_OUTPUT_DIR,
"r_combined_risk_report.csv"
),
row.names = FALSE
)

# ------------------------------------------------------------

# 11. FINAL REPORT

# ------------------------------------------------------------

cat("============================================\n")
cat(" FINAL R RISK REPORT\n")
cat("============================================\n\n")

cat(
sprintf(
"Portfolio Market Value : INR %.2f\n",
total_mv
)
)

cat(
sprintf(
"Modified Duration      : %.6f\n",
portfolio_duration
)
)

cat(
sprintf(
"Convexity              : %.6f\n",
portfolio_convexity
)
)

cat(
sprintf(
"DV01                   : INR %.2f\n",
portfolio_dv01
)
)

cat(
sprintf(
"VaR 95%%                : INR %.2f\n",
var_95
)
)

cat(
sprintf(
"CVaR 95%%               : INR %.2f\n",
cvar_95
)
)

cat("\n")

cat("R OUTPUT FOLDER:\n")

cat(
normalizePath(
R_OUTPUT_DIR,
winslash = "/",
mustWork = FALSE
)
)

cat("\n\n")

cat("FILES CREATED:\n")
cat("--------------------------------------------\n")
cat("1. r_portfolio_summary.csv\n")
cat("2. r_stress_test_results.csv\n")
cat("3. r_krd_analysis.csv\n")
cat("4. r_latest_yield_curve.csv\n")
cat("5. r_curve_scenario_results.csv\n")
cat("6. r_monte_carlo_summary.csv\n")
cat("7. r_ml_model_comparison.csv\n")
cat("8. r_ml_feature_importance.csv\n")
cat("9. r_combined_risk_report.csv\n")

cat("\n============================================\n")
cat(" DAY 6.4 COMPLETE\n")
cat("============================================\n")

cat(
"R implementation finished successfully.\n"
)
