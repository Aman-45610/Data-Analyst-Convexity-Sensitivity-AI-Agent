# ============================================================
# PROJECT 1B
# DAY 4 - MACHINE LEARNING
# Convexity Sensitivity AI Agent
#
# Models:
# 1. Random Forest
# 2. XGBoost
# 3. Neural Network
#
# NOTE:
# This script does NOT use scikit-learn because Windows
# Application Control is blocking sklearn's OpenMP DLL.
# ============================================================

import pandas as pd
import numpy as np
import xgboost as xgb
from pathlib import Path


# ============================================================
# 1. PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"

OUTPUT_DIR.mkdir(exist_ok=True)


# ============================================================
# 2. LOAD PORTFOLIO DATA
# ============================================================

portfolio = pd.read_csv(
    DATA_DIR / "bond_portfolio_data.csv"
)

print("============================================================")
print("DAY 4 - MACHINE LEARNING")
print("============================================================")

print("\n===== ML DATASET =====")
print("Rows:", len(portfolio))
print("Columns:", len(portfolio.columns))


# ============================================================
# 3. FEATURES AND TARGET
# ============================================================

features = [
    "CouponRate",
    "YearsToMaturity",
    "YieldToMaturity",
    "ModifiedDuration",
    "Convexity"
]

target = "PriceChange_Up100bps"

X = portfolio[features].values.astype(float)
y = portfolio[target].values.astype(float)

print("\n===== FEATURES =====")

for feature in features:
    print("-", feature)

print("\nTarget:")
print("-", target)


# ============================================================
# 4. TRAIN / TEST SPLIT
# ============================================================

np.random.seed(42)

indices = np.arange(len(X))
np.random.shuffle(indices)

split = int(len(X) * 0.80)

train_idx = indices[:split]
test_idx = indices[split:]

X_train = X[train_idx]
X_test = X[test_idx]

y_train = y[train_idx]
y_test = y[test_idx]

print("\n===== DATA SPLIT =====")
print("Training rows:", len(X_train))
print("Testing rows:", len(X_test))


# ============================================================
# 5. EVALUATION FUNCTIONS
# ============================================================

def calculate_metrics(actual, predicted):

    mae = np.mean(
        np.abs(actual - predicted)
    )

    rmse = np.sqrt(
        np.mean((actual - predicted) ** 2)
    )

    ss_res = np.sum(
        (actual - predicted) ** 2
    )

    ss_tot = np.sum(
        (actual - np.mean(actual)) ** 2
    )

    r2 = 1 - (ss_res / ss_tot)

    return mae, rmse, r2


# ============================================================
# 6. RANDOM FOREST
# ============================================================
#
# Lightweight Random Forest implementation using NumPy.
# This avoids sklearn completely.
# ============================================================

class DecisionTreeRegressor:

    def __init__(
        self,
        max_depth=5,
        min_samples_split=8,
        random_state=42
    ):

        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.random_state = random_state
        self.root = None
        self.feature_importance = None


    def fit(self, X, y):

        self.n_features = X.shape[1]
        self.feature_importance = np.zeros(
            self.n_features
        )

        self.root = self._build_tree(
            X,
            y,
            depth=0
        )

        return self


    def _build_tree(self, X, y, depth):

        n_samples = len(y)

        # Stop conditions
        if (
            depth >= self.max_depth
            or n_samples < self.min_samples_split
            or np.var(y) < 1e-10
        ):
            return {
                "leaf": True,
                "value": np.mean(y)
            }

        best_feature = None
        best_threshold = None
        best_score = np.inf

        parent_error = np.var(y) * n_samples

        # Try every feature
        for feature in range(X.shape[1]):

            values = X[:, feature]

            # Use percentile thresholds
            thresholds = np.percentile(
                values,
                [20, 40, 60, 80]
            )

            thresholds = np.unique(thresholds)

            for threshold in thresholds:

                left_mask = values <= threshold
                right_mask = values > threshold

                if (
                    left_mask.sum() < 2
                    or right_mask.sum() < 2
                ):
                    continue

                y_left = y[left_mask]
                y_right = y[right_mask]

                error = (
                    np.var(y_left) * len(y_left)
                    +
                    np.var(y_right) * len(y_right)
                )

                if error < best_score:

                    best_score = error
                    best_feature = feature
                    best_threshold = threshold

        # No useful split
        if best_feature is None:
            return {
                "leaf": True,
                "value": np.mean(y)
            }

        # Record feature importance
        improvement = parent_error - best_score

        if improvement > 0:
            self.feature_importance[
                best_feature
            ] += improvement

        left_mask = (
            X[:, best_feature]
            <= best_threshold
        )

        right_mask = ~left_mask

        left_tree = self._build_tree(
            X[left_mask],
            y[left_mask],
            depth + 1
        )

        right_tree = self._build_tree(
            X[right_mask],
            y[right_mask],
            depth + 1
        )

        return {
            "leaf": False,
            "feature": best_feature,
            "threshold": best_threshold,
            "left": left_tree,
            "right": right_tree
        }


    def _predict_row(self, row, node):

        if node["leaf"]:
            return node["value"]

        if row[node["feature"]] <= node["threshold"]:
            return self._predict_row(
                row,
                node["left"]
            )

        return self._predict_row(
            row,
            node["right"]
        )


    def predict(self, X):

        return np.array([
            self._predict_row(row, self.root)
            for row in X
        ])


class RandomForest:

    def __init__(
        self,
        n_trees=30,
        max_depth=5,
        min_samples_split=8,
        random_state=42
    ):

        self.n_trees = n_trees
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.random_state = random_state
        self.trees = []


    def fit(self, X, y):

        rng = np.random.default_rng(
            self.random_state
        )

        self.trees = []

        for i in range(self.n_trees):

            # Bootstrap sample
            sample_indices = rng.choice(
                len(X),
                size=len(X),
                replace=True
            )

            X_sample = X[sample_indices]
            y_sample = y[sample_indices]

            tree = DecisionTreeRegressor(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
                random_state=self.random_state + i
            )

            tree.fit(
                X_sample,
                y_sample
            )

            self.trees.append(tree)

        return self


    def predict(self, X):

        predictions = np.array([
            tree.predict(X)
            for tree in self.trees
        ])

        return np.mean(
            predictions,
            axis=0
        )


    def feature_importances(self):

        importance = np.zeros(
            len(features)
        )

        for tree in self.trees:
            importance += tree.feature_importance

        total = importance.sum()

        if total > 0:
            importance /= total

        return importance


print("\n===== RANDOM FOREST =====")

rf_model = RandomForest(
    n_trees=30,
    max_depth=5,
    min_samples_split=8,
    random_state=42
)

rf_model.fit(
    X_train,
    y_train
)

rf_predictions = rf_model.predict(
    X_test
)

rf_mae, rf_rmse, rf_r2 = calculate_metrics(
    y_test,
    rf_predictions
)

print(f"MAE: {rf_mae:.4f}")
print(f"RMSE: {rf_rmse:.4f}")
print(f"R² Score: {rf_r2:.4f}")

rf_importance = rf_model.feature_importances()


# ============================================================
# 7. XGBOOST
# ============================================================

print("\n===== XGBOOST =====")

dtrain = xgb.DMatrix(
    X_train,
    label=y_train,
    feature_names=features
)

dtest = xgb.DMatrix(
    X_test,
    label=y_test,
    feature_names=features
)

xgb_params = {
    "objective": "reg:squarederror",
    "max_depth": 4,
    "learning_rate": 0.05,
    "subsample": 0.9,
    "colsample_bytree": 0.9,
    "seed": 42
}

xgb_model = xgb.train(
    xgb_params,
    dtrain,
    num_boost_round=200
)

xgb_predictions = xgb_model.predict(
    dtest
)

xgb_mae, xgb_rmse, xgb_r2 = calculate_metrics(
    y_test,
    xgb_predictions
)

print(f"MAE: {xgb_mae:.4f}")
print(f"RMSE: {xgb_rmse:.4f}")
print(f"R² Score: {xgb_r2:.4f}")

xgb_importance_dict = xgb_model.get_score(
    importance_type="gain"
)

xgb_importance = np.array([
    xgb_importance_dict.get(
        feature,
        0
    )
    for feature in features
])

if xgb_importance.sum() > 0:
    xgb_importance /= xgb_importance.sum()


# ============================================================
# 8. NEURAL NETWORK
# ============================================================
#
# Simple feed-forward neural network using NumPy.
# No TensorFlow, PyTorch or sklearn required.
# ============================================================

print("\n===== NEURAL NETWORK =====")


# Standardize input features
X_mean = X_train.mean(axis=0)
X_std = X_train.std(axis=0)

X_std[X_std == 0] = 1

X_train_nn = (
    X_train - X_mean
) / X_std

X_test_nn = (
    X_test - X_mean
) / X_std


# Standardize target
y_mean = y_train.mean()
y_std = y_train.std()

if y_std == 0:
    y_std = 1

y_train_nn = (
    y_train - y_mean
) / y_std


# Network architecture
input_size = X_train_nn.shape[1]
hidden_size = 16
output_size = 1

rng = np.random.default_rng(42)

W1 = rng.normal(
    0,
    np.sqrt(2 / input_size),
    (input_size, hidden_size)
)

b1 = np.zeros(
    (1, hidden_size)
)

W2 = rng.normal(
    0,
    np.sqrt(2 / hidden_size),
    (hidden_size, output_size)
)

b2 = np.zeros(
    (1, output_size)
)


def relu(x):
    return np.maximum(
        0,
        x
    )


def relu_derivative(x):
    return (
        x > 0
    ).astype(float)


learning_rate = 0.01
epochs = 1500

n = len(X_train_nn)


for epoch in range(epochs):

    # Forward pass
    Z1 = (
        X_train_nn @ W1
        + b1
    )

    A1 = relu(Z1)

    Z2 = (
        A1 @ W2
        + b2
    )

    predictions_nn = Z2.flatten()

    # Error
    error = (
        predictions_nn
        - y_train_nn
    )

    # Backpropagation
    dZ2 = (
        2 * error / n
    ).reshape(-1, 1)

    dW2 = (
        A1.T @ dZ2
    )

    db2 = dZ2.sum(
        axis=0,
        keepdims=True
    )

    dA1 = (
        dZ2 @ W2.T
    )

    dZ1 = (
        dA1
        * relu_derivative(Z1)
    )

    dW1 = (
        X_train_nn.T @ dZ1
    )

    db1 = dZ1.sum(
        axis=0,
        keepdims=True
    )

    # Update weights
    W2 -= (
        learning_rate * dW2
    )

    b2 -= (
        learning_rate * db2
    )

    W1 -= (
        learning_rate * dW1
    )

    b1 -= (
        learning_rate * db1
    )


# Neural network prediction
Z1_test = (
    X_test_nn @ W1
    + b1
)

A1_test = relu(
    Z1_test
)

Z2_test = (
    A1_test @ W2
    + b2
)

nn_predictions_standardized = (
    Z2_test.flatten()
)

# Convert back to original target scale
nn_predictions = (
    nn_predictions_standardized
    * y_std
    + y_mean
)

nn_mae, nn_rmse, nn_r2 = calculate_metrics(
    y_test,
    nn_predictions
)

print(f"MAE: {nn_mae:.4f}")
print(f"RMSE: {nn_rmse:.4f}")
print(f"R² Score: {nn_r2:.4f}")


# ============================================================
# 9. MODEL COMPARISON
# ============================================================

comparison = pd.DataFrame({

    "Model": [
        "Random Forest",
        "XGBoost",
        "Neural Network"
    ],

    "MAE": [
        rf_mae,
        xgb_mae,
        nn_mae
    ],

    "RMSE": [
        rf_rmse,
        xgb_rmse,
        nn_rmse
    ],

    "R2": [
        rf_r2,
        xgb_r2,
        nn_r2
    ]
})


print("\n============================================================")
print("MODEL COMPARISON")
print("============================================================")

print(
    comparison.to_string(
        index=False
    )
)


# ============================================================
# 10. FEATURE IMPORTANCE COMPARISON
# ============================================================

feature_importance = pd.DataFrame({

    "Feature": features,

    "RandomForest": rf_importance,

    "XGBoost": xgb_importance
})


print("\n===== FEATURE IMPORTANCE =====")

print(
    feature_importance.to_string(
        index=False
    )
)


# ============================================================
# 11. SAVE RESULTS
# ============================================================

comparison.to_csv(
    OUTPUT_DIR / "ml_model_comparison.csv",
    index=False
)

feature_importance.to_csv(
    OUTPUT_DIR / "ml_feature_importance.csv",
    index=False
)


# ============================================================
# 12. SAVE PREDICTIONS
# ============================================================

prediction_results = pd.DataFrame({

    "Actual": y_test,

    "RandomForest_Prediction": rf_predictions,

    "XGBoost_Prediction": xgb_predictions,

    "NeuralNetwork_Prediction": nn_predictions

})

prediction_results.to_csv(
    OUTPUT_DIR / "ml_predictions.csv",
    index=False
)


print("\n===== FILES SAVED =====")

print(
    "outputs/ml_model_comparison.csv"
)

print(
    "outputs/ml_feature_importance.csv"
)

print(
    "outputs/ml_predictions.csv"
)

print("\n===== DAY 4 ML COMPLETE =====")