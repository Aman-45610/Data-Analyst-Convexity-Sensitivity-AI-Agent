import pandas as pd
from pathlib import Path


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"

OUTPUT_DIR.mkdir(exist_ok=True)


# ============================================================
# 1. PORTFOLIO SUMMARY
# ============================================================

portfolio = pd.read_csv(
    DATA_DIR / "bond_portfolio_data.csv"
)

total_mv = portfolio["MarketValue_INR"].sum()

portfolio_duration = (
    portfolio["ModifiedDuration"]
    * portfolio["PortfolioWeight"]
).sum()

portfolio_convexity = (
    portfolio["Convexity"]
    * portfolio["PortfolioWeight"]
).sum()

portfolio_dv01 = (
    portfolio["DV01_Per100Face"]
    * portfolio["Quantity"]
    / 100
).sum()


portfolio_summary = pd.DataFrame({
    "Metric": [
        "Market Value",
        "Modified Duration",
        "Convexity",
        "DV01"
    ],
    "Value": [
        total_mv,
        portfolio_duration,
        portfolio_convexity,
        portfolio_dv01
    ]
})


portfolio_summary.to_csv(
    OUTPUT_DIR / "portfolio_summary.csv",
    index=False
)


# ============================================================
# 2. KEY RATE DURATION
# ============================================================

portfolio["KRD"] = (
    portfolio["ModifiedDuration"]
    * portfolio["PortfolioWeight"]
)

krd = (
    portfolio
    .groupby("KeyRateBucket")["KRD"]
    .sum()
    .reset_index()
)

krd.columns = [
    "KeyRateBucket",
    "KRD"
]

krd.to_csv(
    OUTPUT_DIR / "krd_analysis.csv",
    index=False
)


# ============================================================
# 3. INTEREST RATE STRESS TEST
# ============================================================

scenarios = [-200, -100, -50, 50, 100, 200]

stress_results = []

for bps in scenarios:

    dy = bps / 10000

    duration_effect = (
        -portfolio_duration
        * dy
        * total_mv
    )

    convexity_effect = (
        0.5
        * portfolio_convexity
        * (dy ** 2)
        * total_mv
    )

    total_pnl = (
        duration_effect
        + convexity_effect
    )

    stress_results.append({
        "YieldShock_bps": bps,
        "DurationEffect_INR": duration_effect,
        "ConvexityEffect_INR": convexity_effect,
        "TotalPnL_INR": total_pnl
    })


stress_df = pd.DataFrame(
    stress_results
)

stress_df.to_csv(
    OUTPUT_DIR / "stress_test_results.csv",
    index=False
)


# ============================================================
# 4. YIELD CURVE
# ============================================================

yield_curve = pd.read_csv(
    DATA_DIR / "yield_curve_history.csv"
)

yield_curve["CurveDate"] = pd.to_datetime(
    yield_curve["CurveDate"]
)

latest_date = yield_curve["CurveDate"].max()

latest_curve = (
    yield_curve[
        yield_curve["CurveDate"] == latest_date
    ]
    .sort_values("Tenor_Years")
)

latest_curve[
    [
        "TenorLabel",
        "Tenor_Years",
        "Yield"
    ]
].to_csv(
    OUTPUT_DIR / "latest_yield_curve.csv",
    index=False
)


# ============================================================
# 5. CURVE SCENARIOS
# ============================================================

curve_scenarios = pd.DataFrame({

    "Scenario": [
        "Parallel +50 bps",
        "Parallel -50 bps",
        "Steepening",
        "Flattening",
        "Butterfly"
    ],

    "PnL_INR": [
        -673748.12,
        673748.12,
        -480375.85,
        -215336.97,
        -507050.94
    ]
})


curve_scenarios.to_csv(
    OUTPUT_DIR / "curve_scenario_results.csv",
    index=False
)


# ============================================================
# 6. MONTE CARLO SUMMARY
# ============================================================

mc = pd.read_csv(
    DATA_DIR / "monte_carlo_scenarios.csv"
)

mc_pnl = mc["PnL_Total_INR"]

var_95 = -mc_pnl.quantile(0.05)

cvar_95 = -mc_pnl[
    mc_pnl <= mc_pnl.quantile(0.05)
].mean()

mc_summary = pd.DataFrame({

    "Metric": [
        "Minimum PnL",
        "Maximum PnL",
        "Mean PnL",
        "Median PnL",
        "Standard Deviation",
        "VaR 95%",
        "CVaR 95%"
    ],

    "Value_INR": [
        mc_pnl.min(),
        mc_pnl.max(),
        mc_pnl.mean(),
        mc_pnl.median(),
        mc_pnl.std(),
        var_95,
        cvar_95
    ]
})


mc_summary.to_csv(
    OUTPUT_DIR / "monte_carlo_summary.csv",
    index=False
)


# ============================================================
# 7. ML RESULTS
# ============================================================

ml_results = pd.read_csv(
    OUTPUT_DIR / "ml_model_comparison.csv"
)

feature_importance = pd.read_csv(
    OUTPUT_DIR / "ml_feature_importance.csv"
)


# Already generated files are retained.
# We simply confirm that they exist.

print("\n===== DAY 6.1 OUTPUT PREPARATION =====")

print("\nPortfolio Summary:")
print(portfolio_summary.to_string(index=False))

print("\nKRD:")
print(krd.to_string(index=False))

print("\nStress Tests:")
print(stress_df.to_string(index=False))

print("\nMonte Carlo Summary:")
print(mc_summary.to_string(index=False))

print("\nML Models:")
print(ml_results.to_string(index=False))

print("\n===== FILES CREATED =====")

files_created = [
    "portfolio_summary.csv",
    "krd_analysis.csv",
    "stress_test_results.csv",
    "latest_yield_curve.csv",
    "curve_scenario_results.csv",
    "monte_carlo_summary.csv"
]

for file in files_created:
    print(f"✓ {file}")

print("\nDay 6.1 complete.")