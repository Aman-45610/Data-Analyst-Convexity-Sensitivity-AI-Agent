import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

portfolio = pd.read_csv(DATA_DIR / "bond_portfolio_data.csv")
yield_curve = pd.read_csv(DATA_DIR / "yield_curve_history.csv")
mc = pd.read_csv(DATA_DIR / "monte_carlo_scenarios.csv")

print("PORTFOLIO")
print(portfolio.shape)

print("\nYIELD CURVE")
print(yield_curve.shape)

print("\nMONTE CARLO")
print(mc.shape)

print("\nMissing values - Portfolio")
print(portfolio.isnull().sum())

print("\nMissing values - Yield Curve")
print(yield_curve.isnull().sum())

print("\nMissing values - Monte Carlo")
print(mc.isnull().sum())