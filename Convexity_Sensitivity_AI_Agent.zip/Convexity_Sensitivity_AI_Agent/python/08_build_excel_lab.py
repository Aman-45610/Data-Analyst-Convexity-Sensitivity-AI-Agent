from pathlib import Path
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.utils import get_column_letter

# ============================================================
# DAY 6.2 - BOND RISK LAB EXCEL BUILDER
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "outputs"
EXCEL_DIR = PROJECT_DIR / "excel"

EXCEL_DIR.mkdir(parents=True, exist_ok=True)

# ============================================================
# LOAD DATA
# ============================================================

required_files = [
    OUTPUT_DIR / "portfolio_summary.csv",
    OUTPUT_DIR / "krd_analysis.csv",
    OUTPUT_DIR / "stress_test_results.csv",
    OUTPUT_DIR / "latest_yield_curve.csv",
    OUTPUT_DIR / "curve_scenario_results.csv",
    OUTPUT_DIR / "monte_carlo_summary.csv",
    OUTPUT_DIR / "ml_model_comparison.csv",
    OUTPUT_DIR / "ml_feature_importance.csv",
    DATA_DIR / "bond_portfolio_data.csv",
]

missing = [str(p) for p in required_files if not p.exists()]

if missing:
    print("ERROR: Required files are missing:")
    for item in missing:
        print(item)
    print()
    print("Run Day 6.1 first, then run this script again.")
    raise SystemExit(1)

portfolio_summary = pd.read_csv(OUTPUT_DIR / "portfolio_summary.csv")
krd = pd.read_csv(OUTPUT_DIR / "krd_analysis.csv")
stress = pd.read_csv(OUTPUT_DIR / "stress_test_results.csv")
yield_curve = pd.read_csv(OUTPUT_DIR / "latest_yield_curve.csv")
curve_scenarios = pd.read_csv(OUTPUT_DIR / "curve_scenario_results.csv")
mc_summary = pd.read_csv(OUTPUT_DIR / "monte_carlo_summary.csv")
ml_models = pd.read_csv(OUTPUT_DIR / "ml_model_comparison.csv")
feature_importance = pd.read_csv(OUTPUT_DIR / "ml_feature_importance.csv")
portfolio = pd.read_csv(DATA_DIR / "bond_portfolio_data.csv")

# ============================================================
# WORKBOOK
# ============================================================

wb = Workbook()
wb.remove(wb.active)

# ============================================================
# STYLES
# ============================================================

thin = Side(style="thin", color="B7B7B7")
border = Border(left=thin, right=thin, top=thin, bottom=thin)

title_fill = PatternFill("solid", fgColor="1F4E78")
section_fill = PatternFill("solid", fgColor="D9EAF7")
header_fill = PatternFill("solid", fgColor="5B9BD5")
level_fill = PatternFill("solid", fgColor="70AD47")

title_font = Font(color="FFFFFF", bold=True, size=16)
header_font = Font(color="FFFFFF", bold=True)
bold_font = Font(bold=True)

currency_format = '₹#,##0.00'
number_format = '#,##0.0000'
percent_format = '0.00%'

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def setup_sheet(ws, title, width=18, merge_to=8):
    ws.sheet_view.showGridLines = False
    ws["A1"] = title
    ws["A1"].fill = title_fill
    ws["A1"].font = title_font
    ws["A1"].alignment = Alignment(horizontal="left")
    ws.merge_cells(
        start_row=1,
        start_column=1,
        end_row=1,
        end_column=merge_to
    )
    for col in range(1, max(merge_to, 14) + 1):
        ws.column_dimensions[get_column_letter(col)].width = width


def write_dataframe(ws, df, start_row=3, start_col=1):
    for j, col in enumerate(df.columns, start_col):
        cell = ws.cell(start_row, j, col)
        cell.fill = header_fill
        cell.font = header_font
        cell.border = border
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True
        )

    for i, row in enumerate(df.itertuples(index=False), start_row + 1):
        for j, value in enumerate(row, start_col):
            if pd.isna(value):
                value = None
            cell = ws.cell(i, j, value)
            cell.border = border
            cell.alignment = Alignment(
                vertical="center",
                wrap_text=True
            )

    return start_row + len(df) + 1


def format_range(ws, min_row, max_row, min_col, max_col, fmt=None):
    for row in ws.iter_rows(
        min_row=min_row,
        max_row=max_row,
        min_col=min_col,
        max_col=max_col
    ):
        for cell in row:
            cell.border = border
            if fmt is not None:
                cell.number_format = fmt


def add_line_chart(ws, title, y_title, x_title, data_col, cat_col, data_start, data_end, position):
    chart = LineChart()
    chart.title = title
    chart.y_axis.title = y_title
    chart.x_axis.title = x_title

    data = Reference(
        ws,
        min_col=data_col,
        min_row=data_start - 1,
        max_row=data_end
    )
    cats = Reference(
        ws,
        min_col=cat_col,
        min_row=data_start,
        max_row=data_end
    )

    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 8
    chart.width = 14
    ws.add_chart(chart, position)


def add_bar_chart(ws, title, y_title, x_title, data_col, cat_col, data_start, data_end, position):
    chart = BarChart()
    chart.type = "col"
    chart.title = title
    chart.y_axis.title = y_title
    chart.x_axis.title = x_title

    data = Reference(
        ws,
        min_col=data_col,
        min_row=data_start - 1,
        max_row=data_end
    )
    cats = Reference(
        ws,
        min_col=cat_col,
        min_row=data_start,
        max_row=data_end
    )

    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 8
    chart.width = 14
    ws.add_chart(chart, position)


# ============================================================
# 1. DASHBOARD
# ============================================================

ws = wb.create_sheet("Dashboard")
setup_sheet(ws, "Bond Risk Lab - Portfolio Risk Dashboard", 20, 8)

metrics = {}
for _, row in portfolio_summary.iterrows():
    metrics[str(row["Metric"])] = float(row["Value"])

ws["A3"] = "Portfolio Risk Metrics"
ws["A3"].fill = section_fill
ws["A3"].font = bold_font

dashboard_metrics = [
    ("Market Value", metrics["Market Value"], currency_format),
    ("Modified Duration", metrics["Modified Duration"], number_format),
    ("Convexity", metrics["Convexity"], number_format),
    ("DV01", metrics["DV01"], currency_format),
]

for row_num, (name, value, fmt) in enumerate(dashboard_metrics, 4):
    ws.cell(row_num, 1, name).font = bold_font
    ws.cell(row_num, 2, value).number_format = fmt
    ws.cell(row_num, 1).border = border
    ws.cell(row_num, 2).border = border

mc_dict = dict(
    zip(
        mc_summary["Metric"].astype(str),
        mc_summary["Value_INR"].astype(float)
    )
)

ws["D3"] = "Monte Carlo Risk"
ws["D3"].fill = section_fill
ws["D3"].font = bold_font

mc_metrics = [
    ("VaR 95%", mc_dict["VaR 95%"]),
    ("CVaR 95%", mc_dict["CVaR 95%"]),
    ("Minimum PnL", mc_dict["Minimum PnL"]),
    ("Maximum PnL", mc_dict["Maximum PnL"]),
]

for row_num, (name, value) in enumerate(mc_metrics, 4):
    ws.cell(row_num, 4, name).font = bold_font
    ws.cell(row_num, 5, value).number_format = currency_format
    ws.cell(row_num, 4).border = border
    ws.cell(row_num, 5).border = border

ws["A10"] = "Key Risk Interpretation"
ws["A10"].fill = section_fill
ws["A10"].font = bold_font

interpretation = [
    "Portfolio duration measures sensitivity to parallel yield movements.",
    "Convexity captures the non-linear component of bond price sensitivity.",
    "DV01 estimates portfolio value change for a 1 basis-point yield movement.",
    "KRD shows where along the yield curve the portfolio has the largest exposure.",
    "Monte Carlo VaR and CVaR summarize downside risk across simulated scenarios."
]

for row_num, text_value in enumerate(interpretation, 11):
    ws.cell(row_num, 1, "• " + text_value)
    ws.merge_cells(
        start_row=row_num,
        start_column=1,
        end_row=row_num,
        end_column=8
    )


# ============================================================
# 2. STRESS TEST
# ============================================================

ws = wb.create_sheet("Stress Test")
setup_sheet(ws, "Yield Shock Stress Test", 18)

write_dataframe(ws, stress, 3)

stress_end = 3 + len(stress)
format_range(ws, 4, stress_end, 1, 1, "0")
format_range(ws, 4, stress_end, 2, 4, currency_format)

add_line_chart(
    ws,
    "Portfolio P&L vs Yield Shock",
    "P&L (INR)",
    "Yield Shock (bps)",
    4,
    1,
    4,
    stress_end,
    "F3"
)


# ============================================================
# 3. KRD ANALYSIS
# ============================================================

ws = wb.create_sheet("KRD Analysis")
setup_sheet(ws, "Key Rate Duration Analysis", 18)

write_dataframe(ws, krd, 3)

krd_end = 3 + len(krd)
format_range(ws, 4, krd_end, 2, 2, number_format)

add_bar_chart(
    ws,
    "Key Rate Duration by Curve Bucket",
    "KRD",
    "Key Rate Bucket",
    2,
    1,
    4,
    krd_end,
    "D3"
)


# ============================================================
# 4. YIELD CURVE
# ============================================================

ws = wb.create_sheet("Yield Curve")
setup_sheet(ws, "Latest Yield Curve", 18)

write_dataframe(ws, yield_curve, 3)

yield_end = 3 + len(yield_curve)

# The Day 6.1 file stores Yield as the third column.
if "Yield" in yield_curve.columns:
    yield_col = list(yield_curve.columns).index("Yield") + 1
else:
    yield_col = 3

format_range(ws, 4, yield_end, yield_col, yield_col, percent_format)

tenor_col = 1
if "TenorLabel" in yield_curve.columns:
    tenor_col = list(yield_curve.columns).index("TenorLabel") + 1

add_line_chart(
    ws,
    "Latest Yield Curve",
    "Yield",
    "Tenor",
    yield_col,
    tenor_col,
    4,
    yield_end,
    "E3"
)


# ============================================================
# 5. CURVE SCENARIOS
# ============================================================

ws = wb.create_sheet("Curve Scenarios")
setup_sheet(ws, "Yield Curve Scenario Analysis", 20)

write_dataframe(ws, curve_scenarios, 3)

scenario_end = 3 + len(curve_scenarios)

# PnL column is normally the second column.
pnl_col = 2
if "PnL_INR" in curve_scenarios.columns:
    pnl_col = list(curve_scenarios.columns).index("PnL_INR") + 1
elif "ScenarioPnL_INR" in curve_scenarios.columns:
    pnl_col = list(curve_scenarios.columns).index("ScenarioPnL_INR") + 1

format_range(ws, 4, scenario_end, pnl_col, pnl_col, currency_format)

scenario_name_col = 1
add_bar_chart(
    ws,
    "Curve Scenario P&L",
    "P&L (INR)",
    "Scenario",
    pnl_col,
    scenario_name_col,
    4,
    scenario_end,
    "D3"
)


# ============================================================
# 6. MONTE CARLO
# ============================================================

ws = wb.create_sheet("Monte Carlo")
setup_sheet(ws, "Monte Carlo Risk Summary", 20)

write_dataframe(ws, mc_summary, 3)

mc_end = 3 + len(mc_summary)
format_range(ws, 4, mc_end, 2, 2, currency_format)

ws["D3"] = "Key Risk Metrics"
ws["D3"].fill = section_fill
ws["D3"].font = bold_font

ws["D4"] = "VaR 95%"
ws["E4"] = mc_dict["VaR 95%"]
ws["D5"] = "CVaR 95%"
ws["E5"] = mc_dict["CVaR 95%"]

ws["E4"].number_format = currency_format
ws["E5"].number_format = currency_format

for cell_ref in ["D4", "E4", "D5", "E5"]:
    ws[cell_ref].border = border


# ============================================================
# 7. ML MODELS
# ============================================================

ws = wb.create_sheet("ML Models")
setup_sheet(ws, "Machine Learning Model Comparison", 20)

write_dataframe(ws, ml_models, 3)

ml_end = 3 + len(ml_models)

for col_name in ["MAE", "RMSE", "R2"]:
    if col_name in ml_models.columns:
        col_num = list(ml_models.columns).index(col_name) + 1
        format_range(ws, 4, ml_end, col_num, col_num, number_format)

if "R2" in ml_models.columns:
    r2_col = list(ml_models.columns).index("R2") + 1
else:
    r2_col = 4

add_bar_chart(
    ws,
    "Model R² Comparison",
    "R²",
    "Model",
    r2_col,
    1,
    4,
    ml_end,
    "F3"
)


# ============================================================
# 8. FEATURE IMPORTANCE
# ============================================================

ws = wb.create_sheet("Feature Importance")
setup_sheet(ws, "XGBoost Feature Importance", 20)

write_dataframe(ws, feature_importance, 3)

fi_end = 3 + len(feature_importance)

importance_col = 2
if "Importance" in feature_importance.columns:
    importance_col = list(feature_importance.columns).index("Importance") + 1

format_range(
    ws,
    4,
    fi_end,
    importance_col,
    importance_col,
    number_format
)

feature_col = 1
if "Feature" in feature_importance.columns:
    feature_col = list(feature_importance.columns).index("Feature") + 1

add_bar_chart(
    ws,
    "XGBoost Feature Importance",
    "Importance",
    "Feature",
    importance_col,
    feature_col,
    4,
    fi_end,
    "D3"
)


# ============================================================
# 9. BOND RISK LAB - SIX LEVELS
# ============================================================

ws = wb.create_sheet("Bond Risk Lab")
setup_sheet(
    ws,
    "Bond Risk Lab - Six-Level Training Campaign",
    24,
    8
)

headers = [
    "Level",
    "Mission",
    "Objective",
    "Data / Concept",
    "Task",
    "Expected Output",
    "Status"
]

for col_num, header in enumerate(headers, 1):
    cell = ws.cell(3, col_num, header)
    cell.fill = header_fill
    cell.font = header_font
    cell.border = border
    cell.alignment = Alignment(
        horizontal="center",
        vertical="center",
        wrap_text=True
    )

levels = [
    [
        "Level 1",
        "Rate Shock Rookie",
        "Understand basic duration sensitivity",
        "Modified Duration + Yield Shock",
        "Calculate P&L for ±50 bps and ±100 bps",
        "Correct direction and approximate P&L",
        "READY"
    ],
    [
        "Level 2",
        "Convexity Explorer",
        "Understand non-linear price sensitivity",
        "Duration + Convexity",
        "Compare duration-only and duration+convexity P&L",
        "Explain convexity contribution",
        "READY"
    ],
    [
        "Level 3",
        "Curve Strategist",
        "Analyze non-parallel curve movements",
        "KRD + Yield Curve Scenarios",
        "Evaluate parallel, steepening, flattening and butterfly",
        "Identify scenario P&L",
        "READY"
    ],
    [
        "Level 4",
        "Monte Carlo Trader",
        "Measure portfolio downside risk",
        "1,000 Monte Carlo scenarios",
        "Interpret VaR and CVaR",
        "Report 95% VaR/CVaR",
        "READY"
    ],
    [
        "Level 5",
        "ML Risk Analyst",
        "Compare machine learning approaches",
        "RF + XGBoost + Neural Network",
        "Compare MAE, RMSE and R²",
        "Identify model performance differences",
        "READY"
    ],
    [
        "Level 6",
        "Crisis Risk Manager",
        "Combine all risk analytics",
        "Duration + Convexity + KRD + MC + ML",
        "Explain portfolio behavior under a crisis shock",
        "Integrated risk assessment",
        "READY"
    ]
]

for row_num, level in enumerate(levels, 4):
    for col_num, value in enumerate(level, 1):
        cell = ws.cell(row_num, col_num, value)
        cell.border = border
        cell.alignment = Alignment(
            vertical="top",
            wrap_text=True
        )
        if col_num == 1:
            cell.fill = level_fill
            cell.font = Font(color="FFFFFF", bold=True)

ws["A12"] = "Suggested Scoring"
ws["A12"].fill = section_fill
ws["A12"].font = bold_font

score_headers = ["Level", "Points", "Completion Rule"]

for col_num, header in enumerate(score_headers, 1):
    cell = ws.cell(13, col_num, header)
    cell.fill = header_fill
    cell.font = header_font
    cell.border = border

scores = [
    ("Level 1", 100, "Correct duration shock calculation"),
    ("Level 2", 150, "Correct convexity interpretation"),
    ("Level 3", 200, "Correct curve scenario interpretation"),
    ("Level 4", 200, "Correct VaR/CVaR interpretation"),
    ("Level 5", 150, "Correct ML comparison"),
    ("Level 6", 200, "Integrated risk explanation")
]

for row_num, score_row in enumerate(scores, 14):
    for col_num, value in enumerate(score_row, 1):
        cell = ws.cell(row_num, col_num, value)
        cell.border = border

ws["E12"] = "Total Possible Score"
ws["E12"].fill = section_fill
ws["E12"].font = bold_font
ws["F12"] = "=SUM(B14:B19)"
ws["F12"].font = bold_font
ws["F12"].border = border


# ============================================================
# 10. PORTFOLIO DATA
# ============================================================

ws = wb.create_sheet("Portfolio Data")
setup_sheet(ws, "Bond Portfolio Source Data", 16)

columns = [
    "BondID",
    "Issuer",
    "Sector",
    "CreditRating",
    "Currency",
    "FaceValue",
    "CouponRate",
    "YearsToMaturity",
    "YieldToMaturity",
    "ModifiedDuration",
    "Convexity",
    "DV01_Per100Face",
    "KeyRateBucket",
    "MarketValue_INR",
    "PortfolioWeight"
]

available = [col for col in columns if col in portfolio.columns]
portfolio_subset = portfolio[available].copy()

write_dataframe(ws, portfolio_subset, 3)

portfolio_end = 3 + len(portfolio_subset)

for col_name in [
    "FaceValue",
    "DV01_Per100Face",
    "MarketValue_INR"
]:
    if col_name in portfolio_subset.columns:
        col_num = list(portfolio_subset.columns).index(col_name) + 1
        format_range(
            ws,
            4,
            portfolio_end,
            col_num,
            col_num,
            currency_format
        )

for col_name in [
    "CouponRate",
    "YieldToMaturity",
    "PortfolioWeight"
]:
    if col_name in portfolio_subset.columns:
        col_num = list(portfolio_subset.columns).index(col_name) + 1
        format_range(
            ws,
            4,
            portfolio_end,
            col_num,
            col_num,
            percent_format
        )

for col_name in [
    "ModifiedDuration",
    "Convexity",
    "YearsToMaturity"
]:
    if col_name in portfolio_subset.columns:
        col_num = list(portfolio_subset.columns).index(col_name) + 1
        format_range(
            ws,
            4,
            portfolio_end,
            col_num,
            col_num,
            number_format
        )


# ============================================================
# FINAL FORMATTING
# ============================================================

for sheet in wb.worksheets:
    sheet.freeze_panes = "A4"
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0

    for row in sheet.iter_rows():
        for cell in row:
            if cell.value is not None and cell.row >= 3:
                cell.alignment = Alignment(
                    vertical="center",
                    wrap_text=True
                )

# Open Dashboard first
wb.active = wb.sheetnames.index("Dashboard")

# ============================================================
# SAVE
# ============================================================

output_file = EXCEL_DIR / "Bond_Risk_Lab.xlsx"
wb.save(output_file)

print()
print("==============================================")
print("DAY 6.2 - EXCEL BOND RISK LAB")
print("==============================================")
print()
print("Excel file created successfully:")
print(output_file)
print()
print("Sheets created:")

for sheet_name in wb.sheetnames:
    print("✓ " + sheet_name)

print()
print("Day 6.2 complete.")
