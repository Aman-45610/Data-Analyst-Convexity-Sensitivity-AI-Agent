
# ============================================================
# PROJECT 1B
# DAY 5 - STEP 5.3
# AI BOND RISK AGENT
#
# Includes:
# 1. Duration / Convexity
# 2. DV01
# 3. Monte Carlo VaR / CVaR
# 4. Machine Learning results
# 5. Parallel rate shocks
# 6. Yield curve scenarios
# 7. Key Rate Duration
# 8. Natural-language interaction
#
# Curve scenarios use the EXACT methodology from Day 2.
# ============================================================

import pandas as pd
import numpy as np
import re
from pathlib import Path


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"


# ============================================================
# LOAD PORTFOLIO DATA
# ============================================================

portfolio = pd.read_csv(
    DATA_DIR / "bond_portfolio_data.csv"
)


# ============================================================
# PORTFOLIO RISK METRICS
# ============================================================

total_mv = portfolio["MarketValue_INR"].sum()

portfolio_duration = (
    portfolio["ModifiedDuration"]
    * portfolio["PortfolioWeight"]
).sum()

portfolio_convexity = (
    portfolio["Convexity"]
    * portfolio["PortfolioWeight"]
).sum()

portfolio_dv01 = (
    portfolio["DV01_Per100Face"]
    * portfolio["Quantity"]
    / 100
).sum()


# ============================================================
# KEY RATE DURATION
# ============================================================

portfolio["KRD"] = (
    portfolio["ModifiedDuration"]
    * portfolio["PortfolioWeight"]
)

krd = (
    portfolio
    .groupby("KeyRateBucket")["KRD"]
    .sum()
    .sort_index()
)


# ============================================================
# LOAD YIELD CURVE
# ============================================================

yield_curve = pd.read_csv(
    DATA_DIR / "yield_curve_history.csv"
)

latest_curve_date = yield_curve["CurveDate"].max()

latest_curve = yield_curve[
    yield_curve["CurveDate"] == latest_curve_date
].copy()


# ============================================================
# LOAD MONTE CARLO RESULTS
# ============================================================

mc = pd.read_csv(
    DATA_DIR / "monte_carlo_scenarios.csv"
)

mc_pnl = mc["PnL_Total_INR"]

mc_5th_percentile = mc_pnl.quantile(0.05)

var_95 = -mc_5th_percentile

cvar_95 = -mc_pnl[
    mc_pnl <= mc_5th_percentile
].mean()


# ============================================================
# LOAD MACHINE LEARNING RESULTS
# ============================================================

ml_results = pd.read_csv(
    OUTPUT_DIR / "ml_model_comparison.csv"
)

feature_importance_df = pd.read_csv(
    OUTPUT_DIR / "ml_feature_importance.csv"
)


# ============================================================
# DURATION + CONVEXITY STRESS TEST
# ============================================================

def calculate_stress(bps):

    dy = bps / 10000

    duration_effect = (
        -portfolio_duration
        * dy
        * total_mv
    )

    convexity_effect = (
        0.5
        * portfolio_convexity
        * (dy ** 2)
        * total_mv
    )

    total_pnl = (
        duration_effect
        + convexity_effect
    )

    return (
        duration_effect,
        convexity_effect,
        total_pnl
    )


# ============================================================
# EXACT DAY 2 CURVE SCENARIOS
# ============================================================

def calculate_krd_scenario(scenario):

    scenario = scenario.lower()

    scenario_shocks = {

        # ----------------------------------------
        # PARALLEL +50 BPS
        # ----------------------------------------

        "parallel_up": {

            "0-1Y": 50,
            "1-2Y": 50,
            "2-3Y": 50,
            "3-5Y": 50,
            "5-7Y": 50,
            "7-10Y": 50,
            "10-15Y": 50,
            "15-20Y": 50,
            "20Y+": 50
        },


        # ----------------------------------------
        # PARALLEL -50 BPS
        # ----------------------------------------

        "parallel_down": {

            "0-1Y": -50,
            "1-2Y": -50,
            "2-3Y": -50,
            "3-5Y": -50,
            "5-7Y": -50,
            "7-10Y": -50,
            "10-15Y": -50,
            "15-20Y": -50,
            "20Y+": -50
        },


        # ----------------------------------------
        # STEEPENING
        # ----------------------------------------

        "steepening": {

            "0-1Y": 5,
            "1-2Y": 10,
            "2-3Y": 15,
            "3-5Y": 20,
            "5-7Y": 30,
            "7-10Y": 40,
            "10-15Y": 42,
            "15-20Y": 45,
            "20Y+": 50
        },


        # ----------------------------------------
        # FLATTENING
        # ----------------------------------------

        "flattening": {

            "0-1Y": 50,
            "1-2Y": 45,
            "2-3Y": 40,
            "3-5Y": 30,
            "5-7Y": 20,
            "7-10Y": 15,
            "10-15Y": 10,
            "15-20Y": 5,
            "20Y+": 0
        },


        # ----------------------------------------
        # BUTTERFLY
        # ----------------------------------------

        "butterfly": {

            "0-1Y": 10,
            "1-2Y": 20,
            "2-3Y": 30,
            "3-5Y": 40,
            "5-7Y": 50,
            "7-10Y": 50,
            "10-15Y": 50,
            "15-20Y": 40,
            "20Y+": 20
        }
    }


    # Check scenario

    if scenario not in scenario_shocks:

        return None


    # Get bucket shocks

    shock_weights = scenario_shocks[scenario]


    # Calculate P&L

    scenario_pnl = 0

    for bucket, duration in krd.items():

        shift_bps = shock_weights.get(
            bucket,
            0
        )

        shift = shift_bps / 10000

        scenario_pnl += (
            -duration
            * shift
            * total_mv
        )


    return (
        shock_weights,
        scenario_pnl
    )


# ============================================================
# DISPLAY KRD
# ============================================================

def show_krd():

    print("\n----- KEY RATE DURATION -----")

    for bucket, value in krd.items():

        print(
            f"{bucket}: {value:.4f}"
        )


# ============================================================
# DISPLAY CURVE SCENARIO
# ============================================================

def show_curve_scenario(scenario_name):

    result = calculate_krd_scenario(
        scenario_name
    )

    if result is None:

        print(
            "\nUnknown curve scenario."
        )

        return


    shocks, pnl = result


    print(
        "\n============================================================"
    )

    print(
        f"YIELD CURVE SCENARIO: "
        f"{scenario_name.upper()}"
    )

    print(
        "============================================================"
    )


    print(
        "\nKey-rate bucket shocks:"
    )


    for bucket, shock in shocks.items():

        print(
            f"{bucket}: {shock:+.0f} bps"
        )


    print(
        f"\nEstimated Scenario P&L: "
        f"₹{pnl:,.2f}"
    )


    print(
        "============================================================"
    )


# ============================================================
# DISPLAY MACHINE LEARNING RESULTS
# ============================================================

def show_ml_results():

    print(
        "\n----- ML MODEL RESULTS -----"
    )

    print(
        ml_results.to_string(
            index=False
        )
    )


    print(
        "\n----- XGBOOST FEATURE IMPORTANCE -----"
    )


    sorted_features = (
        feature_importance_df
        .sort_values(
            "XGBoost",
            ascending=False
        )
    )


    for _, row in sorted_features.iterrows():

        print(
            f"{row['Feature']}: "
            f"{row['XGBoost']:.4f}"
        )


# ============================================================
# AI RISK AGENT
# ============================================================

def risk_agent(bps):

    duration, convexity, total = (
        calculate_stress(bps)
    )


    if total >= 0:

        direction = "gain"

    else:

        direction = "loss"


    print(
        "\n============================================================"
    )

    print(
        "AI BOND RISK AGENT"
    )

    print(
        "============================================================"
    )


    print(
        f"\nScenario: "
        f"Interest-rate change of "
        f"{bps:+.0f} bps"
    )


    print(
        f"\nPortfolio Market Value: "
        f"₹{total_mv:,.2f}"
    )


    print(
        f"Modified Duration: "
        f"{portfolio_duration:.4f}"
    )


    print(
        f"Convexity: "
        f"{portfolio_convexity:.4f}"
    )


    print(
        f"DV01: "
        f"₹{portfolio_dv01:,.2f}"
    )


    # ----------------------------------------
    # SENSITIVITY
    # ----------------------------------------

    print(
        "\n----- SENSITIVITY ANALYSIS -----"
    )


    print(
        f"Duration Effect: "
        f"₹{duration:,.2f}"
    )


    print(
        f"Convexity Effect: "
        f"₹{convexity:,.2f}"
    )


    print(
        f"Estimated Total P&L: "
        f"₹{total:,.2f}"
    )


    print(
        f"\nThe portfolio is estimated "
        f"to experience a "
        f"₹{abs(total):,.2f} "
        f"{direction}."
    )


    # ----------------------------------------
    # MONTE CARLO
    # ----------------------------------------

    print(
        "\n----- MONTE CARLO RISK -----"
    )


    print(
        f"95% VaR: "
        f"₹{var_95:,.2f}"
    )


    print(
        f"95% CVaR: "
        f"₹{cvar_95:,.2f}"
    )


    # ----------------------------------------
    # KRD
    # ----------------------------------------

    show_krd()


    # ----------------------------------------
    # ML
    # ----------------------------------------

    show_ml_results()


    print(
        "\n============================================================"
    )


# ============================================================
# START AGENT
# ============================================================

print(
    "\n============================================================"
)

print(
    "WELCOME TO THE BOND RISK AI AGENT"
)

print(
    "============================================================"
)


print("\nExamples:")

print(
    "  What happens if rates rise 100 bps?"
)

print(
    "  What happens if rates fall 50 bps?"
)

print(
    "  What happens with a 200 bps increase?"
)

print(
    "  Show parallel up"
)

print(
    "  Show parallel down"
)

print(
    "  Show steepening scenario"
)

print(
    "  Show flattening scenario"
)

print(
    "  Show butterfly scenario"
)

print(
    "  Show KRD"
)

print(
    "  Show ML results"
)

print(
    "  exit"
)


# ============================================================
# INTERACTIVE AGENT
# ============================================================

while True:

    question = input(
        "\nEnter your question: "
    )


    question_lower = (
        question
        .lower()
        .strip()
    )


    # ----------------------------------------
    # EXIT
    # ----------------------------------------

    if question_lower in [
        "exit",
        "quit",
        "q"
    ]:

        print(
            "\nAI Risk Agent closed."
        )

        break


    # ----------------------------------------
    # KRD
    # ----------------------------------------

    if (
        "krd" in question_lower
        or "key rate" in question_lower
    ):

        show_krd()

        continue


    # ----------------------------------------
    # MACHINE LEARNING
    # ----------------------------------------

    if (
        "machine learning"
        in question_lower

        or "ml"
        in question_lower

        or "model"
        in question_lower

        or "feature importance"
        in question_lower
    ):

        show_ml_results()

        continue


    # ----------------------------------------
    # STEEPENING
    # ----------------------------------------

    if (
        "steepen"
        in question_lower

        or "steepening"
        in question_lower
    ):

        show_curve_scenario(
            "steepening"
        )

        continue


    # ----------------------------------------
    # FLATTENING
    # ----------------------------------------

    if (
        "flatten"
        in question_lower

        or "flattening"
        in question_lower
    ):

        show_curve_scenario(
            "flattening"
        )

        continue


    # ----------------------------------------
    # BUTTERFLY
    # ----------------------------------------

    if "butterfly" in question_lower:

        show_curve_scenario(
            "butterfly"
        )

        continue


    # ----------------------------------------
    # PARALLEL DOWN
    # ----------------------------------------

    if (
        "parallel" in question_lower
        and "down" in question_lower
    ):

        show_curve_scenario(
            "parallel_down"
        )

        continue


    # ----------------------------------------
    # PARALLEL UP
    # ----------------------------------------

    if (
        "parallel" in question_lower
        and "up" in question_lower
    ):

        show_curve_scenario(
            "parallel_up"
        )

        continue


    # ----------------------------------------
    # INTEREST-RATE SHOCK
    # ----------------------------------------

    numbers = re.findall(
        r"[-+]?\d+(?:\.\d+)?",
        question_lower
    )


    if not numbers:

        print(
            "\nI couldn't identify an "
            "interest-rate shock or "
            "recognized risk request."
        )


        print("\nTry:")

        print(
            "  +100 bps"
        )

        print(
            "  -50 bps"
        )

        print(
            "  steepening"
        )

        print(
            "  flattening"
        )

        print(
            "  butterfly"
        )

        print(
            "  KRD"
        )

        continue


    bps = float(
        numbers[0]
    )


    # ----------------------------------------
    # DETECT FALLING RATES
    # ----------------------------------------

    negative_words = [

        "fall",
        "falls",
        "decrease",
        "decreases",
        "drop",
        "drops",
        "down",
        "lower",
        "decline"

    ]


    if (
        any(
            word in question_lower
            for word in negative_words
        )
        and bps > 0
    ):

        bps = -bps


    # ----------------------------------------
    # RUN RISK AGENT
    # ----------------------------------------

        risk_agent(
        bps
    )
