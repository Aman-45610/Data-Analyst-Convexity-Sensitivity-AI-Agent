import pandas as pd
from pathlib import Path

# =========================
# LOAD DATA
# =========================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

mc = pd.read_csv(
    DATA_DIR / "monte_carlo_scenarios.csv"
)

print("===== MONTE CARLO DATA =====")

print("Scenarios:", len(mc))

print("\nColumns:")
print(mc.columns.tolist())

# =========================
# BASIC P&L STATISTICS
# =========================

pnl = mc["PnL_Total_INR"]

print("\n===== P&L STATISTICS =====")

print(f"Minimum P&L: ₹{pnl.min():,.2f}")
print(f"Maximum P&L: ₹{pnl.max():,.2f}")
print(f"Mean P&L: ₹{pnl.mean():,.2f}")
print(f"Median P&L: ₹{pnl.median():,.2f}")
print(f"Standard Deviation: ₹{pnl.std():,.2f}")

# =========================
# VaR 95%
# =========================

pnl_5th = pnl.quantile(0.05)

var_95 = -pnl_5th

print("\n===== VaR =====")

print(f"5th Percentile P&L: ₹{pnl_5th:,.2f}")
print(f"VaR 95%: ₹{var_95:,.2f}")

# =========================
# CVaR 95%
# =========================

worst_5_percent = pnl[pnl <= pnl_5th]

cvar_95 = -worst_5_percent.mean()

print("\n===== CVaR =====")

print(f"CVaR 95%: ₹{cvar_95:,.2f}")

# =========================
# WORST 10 SCENARIOS
# =========================

print("\n===== WORST 10 SCENARIOS =====")

worst = mc.sort_values(
    "PnL_Total_INR"
).head(10)

print(
    worst[
        [
            "ScenarioID",
            "ParallelShift_bps",
            "TwistFactor_bps",
            "ButterflyFactor_bps",
            "PnL_Total_INR"
        ]
    ].to_string(index=False)
)
# =========================
# RISK DRIVER CORRELATIONS
# =========================

print("\n===== RISK DRIVER CORRELATIONS =====")

correlations = mc[
    [
        "ParallelShift_bps",
        "TwistFactor_bps",
        "ButterflyFactor_bps",
        "PnL_Total_INR"
    ]
].corr()

print(correlations["PnL_Total_INR"].sort_values())

# =========================
# CREATE OUR OWN MONTE CARLO
# =========================

import numpy as np

# Portfolio values from Day 1
portfolio_mv = 32059345.97
portfolio_duration = 4.2031307717
portfolio_convexity = 44.0613794947

# Reproducible random numbers
np.random.seed(42)

# Number of simulations
n_simulations = 1000

# Generate random yield shocks
# Mean = 0 bps
# Standard deviation = 100 bps
shocks_bps = np.random.normal(
    loc=0,
    scale=100,
    size=n_simulations
)

# Convert bps to decimal yield change
dy = shocks_bps / 10000

# Duration effect
duration_pnl = (
    -portfolio_duration
    * dy
    * portfolio_mv
)

# Convexity effect
convexity_pnl = (
    0.5
    * portfolio_convexity
    * (dy ** 2)
    * portfolio_mv
)

# Total P&L
total_pnl = (
    duration_pnl
    + convexity_pnl
)

# Create results dataframe
simulation = pd.DataFrame({
    "Shock_bps": shocks_bps,
    "Duration_PnL": duration_pnl,
    "Convexity_PnL": convexity_pnl,
    "Total_PnL": total_pnl
})

# =========================
# SIMULATION RESULTS
# =========================

print("\n===== OUR MONTE CARLO SIMULATION =====")

print(f"Simulations: {n_simulations}")

print(
    f"Minimum P&L: ₹{simulation['Total_PnL'].min():,.2f}"
)

print(
    f"Maximum P&L: ₹{simulation['Total_PnL'].max():,.2f}"
)

print(
    f"Mean P&L: ₹{simulation['Total_PnL'].mean():,.2f}"
)

# =========================
# VaR
# =========================

sim_pnl = simulation["Total_PnL"]

sim_5th = sim_pnl.quantile(0.05)

sim_var_95 = -sim_5th

print("\n===== SIMULATION VaR =====")

print(f"VaR 95%: ₹{sim_var_95:,.2f}")

# =========================
# CVaR
# =========================

sim_worst = sim_pnl[
    sim_pnl <= sim_5th
]

sim_cvar_95 = -sim_worst.mean()

print("\n===== SIMULATION CVaR =====")

print(f"CVaR 95%: ₹{sim_cvar_95:,.2f}")

# =========================
# MONTE CARLO DISTRIBUTION
# =========================

import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))

plt.hist(
    simulation["Total_PnL"],
    bins=40
)

plt.axvline(
    -sim_var_95,
    linestyle="--",
    linewidth=2,
    label="95% VaR"
)

plt.title("Monte Carlo Portfolio P&L Distribution")
plt.xlabel("Portfolio P&L (INR)")
plt.ylabel("Frequency")

plt.legend()

plt.tight_layout()

plt.savefig(
    BASE_DIR / "outputs" / "monte_carlo_distribution.png",
    dpi=300
)

plt.show()
print("\n===== MONTE CARLO RISK REPORT =====")

print(f"Portfolio VaR (95%): ₹{sim_var_95:,.2f}")
print(f"Portfolio CVaR (95%): ₹{sim_cvar_95:,.2f}")

worst_scenario = simulation.loc[
    simulation["Total_PnL"].idxmin()
]

print(f"Worst Scenario Shock: {worst_scenario['Shock_bps']:.2f} bps")
print(f"Worst Scenario P&L: ₹{worst_scenario['Total_PnL']:,.2f}")

print("\nRisk Interpretation:")
print("Higher positive yield shocks create larger portfolio losses.")
print("Convexity partially offsets duration losses during large upward shocks.")