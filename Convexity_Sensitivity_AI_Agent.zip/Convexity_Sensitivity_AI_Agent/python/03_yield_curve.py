import pandas as pd
from pathlib import Path

# =========================
# LOAD DATA
# =========================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

yield_curve = pd.read_csv(
    DATA_DIR / "yield_curve_history.csv"
)

# Convert date
yield_curve["CurveDate"] = pd.to_datetime(
    yield_curve["CurveDate"]
)


# =========================
# BASIC INFORMATION
# =========================

print("===== YIELD CURVE DATA =====")

print("Rows:", len(yield_curve))
print("Columns:", len(yield_curve.columns))

print("\nDates:")
print(yield_curve["CurveDate"].min())
print(yield_curve["CurveDate"].max())

print("\nTenors:")
print(
    yield_curve["TenorLabel"]
    .drop_duplicates()
    .tolist()
)


# =========================
# LATEST YIELD CURVE
# =========================

latest_date = yield_curve["CurveDate"].max()

latest_curve = (
    yield_curve[
        yield_curve["CurveDate"] == latest_date
    ]
    .sort_values("Tenor_Years")
)

print("\n===== LATEST YIELD CURVE =====")
print(
    latest_curve[
        ["TenorLabel", "Tenor_Years", "Yield"]
    ].to_string(index=False)
)
# =========================
# YIELD CURVE SCENARIOS
# =========================

# Use the latest curve as the base
base_curve = latest_curve.copy()

# --------------------------------
# 1. PARALLEL SHIFT
# --------------------------------

parallel_shift_bps = 50

base_curve["Parallel_Up"] = (
    base_curve["Yield"] +
    parallel_shift_bps / 10000
)

base_curve["Parallel_Down"] = (
    base_curve["Yield"] -
    parallel_shift_bps / 10000
)


# --------------------------------
# 2. STEEPENING
# --------------------------------

# Short maturities move less,
# long maturities move more

base_curve["Steepening"] = (
    base_curve["Yield"] +
    (base_curve["Tenor_Years"] / 30) *
    (parallel_shift_bps / 10000)
)


# --------------------------------
# 3. FLATTENING
# --------------------------------

# Short maturities move more,
# long maturities move less

base_curve["Flattening"] = (
    base_curve["Yield"] +
    (1 - base_curve["Tenor_Years"] / 30) *
    (parallel_shift_bps / 10000)
)


# =========================
# DISPLAY RESULTS
# =========================

print("\n===== YIELD CURVE SCENARIOS =====")

print(
    base_curve[
        [
            "TenorLabel",
            "Yield",
            "Parallel_Up",
            "Parallel_Down",
            "Steepening",
            "Flattening"
        ]
    ].to_string(index=False)
)
# --------------------------------
# 4. BUTTERFLY SCENARIO
# --------------------------------

butterfly_shift_bps = 50

# Middle maturities receive the largest shock
# Short and long maturities receive smaller shocks

base_curve["Butterfly"] = (
    base_curve["Yield"] +
    butterfly_shift_bps / 10000 *
    (
        1 -
        abs(base_curve["Tenor_Years"] - 10) / 20
    ).clip(lower=0)
)


# =========================
# DISPLAY BUTTERFLY
# =========================

print("\n===== BUTTERFLY SCENARIO =====")

print(
    base_curve[
        [
            "TenorLabel",
            "Yield",
            "Butterfly"
        ]
    ].to_string(index=False)
)
# =========================
# PORTFOLIO CURVE P&L
# =========================

portfolio = pd.read_csv(
    DATA_DIR / "bond_portfolio_data.csv"
)

# Portfolio market value
total_mv = portfolio["MarketValue_INR"].sum()

# Key Rate Duration
portfolio["KRD"] = (
    portfolio["ModifiedDuration"] *
    portfolio["PortfolioWeight"]
)

krd = (
    portfolio
    .groupby("KeyRateBucket")["KRD"]
    .sum()
)

# Map curve tenors to portfolio buckets
bucket_mapping = {
    "0-1Y": 0.5,
    "1-2Y": 1.5,
    "2-3Y": 2.5,
    "3-5Y": 4.0,
    "5-7Y": 6.0,
    "7-10Y": 8.5,
    "10-15Y": 12.5,
    "15-20Y": 17.5,
    "20Y+": 25.0
}

print("\n===== PORTFOLIO KEY RATE EXPOSURE =====")

for bucket, value in krd.items():
    print(f"{bucket}: {value:.4f}")

# =========================
# CURVE SCENARIO P&L
# =========================

def scenario_pnl(shifts):
    """
    Calculate portfolio P&L from KRD and
    yield shifts for each key-rate bucket.
    """

    pnl = 0

    for bucket, duration in krd.items():

        shift_bps = shifts.get(bucket, 0)

        shift = shift_bps / 10000

        pnl += (
            -duration
            * shift
            * total_mv
        )

    return pnl


# =========================
# SCENARIO SHOCKS
# =========================

scenarios = {

    "Parallel +50 bps": {
        "0-1Y": 50,
        "1-2Y": 50,
        "2-3Y": 50,
        "3-5Y": 50,
        "5-7Y": 50,
        "7-10Y": 50,
        "10-15Y": 50,
        "15-20Y": 50,
        "20Y+": 50
    },

    "Parallel -50 bps": {
        "0-1Y": -50,
        "1-2Y": -50,
        "2-3Y": -50,
        "3-5Y": -50,
        "5-7Y": -50,
        "7-10Y": -50,
        "10-15Y": -50,
        "15-20Y": -50,
        "20Y+": -50
    },

    "Steepening": {
        "0-1Y": 5,
        "1-2Y": 10,
        "2-3Y": 15,
        "3-5Y": 20,
        "5-7Y": 30,
        "7-10Y": 40,
        "10-15Y": 42,
        "15-20Y": 45,
        "20Y+": 50
    },

    "Flattening": {
        "0-1Y": 50,
        "1-2Y": 45,
        "2-3Y": 40,
        "3-5Y": 30,
        "5-7Y": 20,
        "7-10Y": 15,
        "10-15Y": 10,
        "15-20Y": 5,
        "20Y+": 0
    },

    "Butterfly": {
        "0-1Y": 10,
        "1-2Y": 20,
        "2-3Y": 30,
        "3-5Y": 40,
        "5-7Y": 50,
        "7-10Y": 50,
        "10-15Y": 50,
        "15-20Y": 40,
        "20Y+": 20
    }
}


# =========================
# RESULTS
# =========================

print("\n===== CURVE SCENARIO P&L =====")

for name, shifts in scenarios.items():

    pnl = scenario_pnl(shifts)

    print(f"{name}: ₹{pnl:,.2f}")