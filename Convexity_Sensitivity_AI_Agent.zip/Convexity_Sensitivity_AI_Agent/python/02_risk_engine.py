import pandas as pd
from pathlib import Path

# =========================
# LOAD DATA
# =========================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

portfolio = pd.read_csv(DATA_DIR / "bond_portfolio_data.csv")


# =========================
# 1. PORTFOLIO RISK METRICS
# =========================

total_mv = portfolio["MarketValue_INR"].sum()

portfolio_duration = (
    portfolio["ModifiedDuration"] *
    portfolio["PortfolioWeight"]
).sum()

portfolio_convexity = (
    portfolio["Convexity"] *
    portfolio["PortfolioWeight"]
).sum()

portfolio_dv01 = (
    portfolio["DV01_Per100Face"] *
    portfolio["Quantity"] / 100
).sum()


print("===== PORTFOLIO RISK METRICS =====")

print(f"Market Value: ₹{total_mv:,.2f}")
print(f"Modified Duration: {portfolio_duration:.4f}")
print(f"Convexity: {portfolio_convexity:.4f}")
print(f"DV01: ₹{portfolio_dv01:,.2f}")


# =========================
# 2. INTEREST RATE STRESS TEST
# =========================

def calculate_stress(bps):

    # Convert basis points to decimal
    dy = bps / 10000

    # Duration effect
    duration_effect = (
        -portfolio_duration *
        dy *
        total_mv
    )

    # Convexity effect
    convexity_effect = (
        0.5 *
        portfolio_convexity *
        (dy ** 2) *
        total_mv
    )

    # Total estimated P&L
    total_pnl = duration_effect + convexity_effect

    return duration_effect, convexity_effect, total_pnl


scenarios = [-200, -100, -50, 50, 100, 200]

print("\n===== INTEREST RATE STRESS TEST =====")

for bps in scenarios:

    duration, convexity, total = calculate_stress(bps)

    print(f"\nYield Shock: {bps:+} bps")
    print(f"Duration Effect: ₹{duration:,.2f}")
    print(f"Convexity Effect: ₹{convexity:,.2f}")
    print(f"Total Estimated P&L: ₹{total:,.2f}")


# =========================
# 3. KEY RATE DURATION
# =========================

portfolio["KRD"] = (
    portfolio["ModifiedDuration"] *
    portfolio["PortfolioWeight"]
)

krd = (
    portfolio
    .groupby("KeyRateBucket")["KRD"]
    .sum()
    .sort_index()
)

print("\n===== KEY RATE DURATION =====")

for bucket, value in krd.items():

    print(f"{bucket}: {value:.4f}")